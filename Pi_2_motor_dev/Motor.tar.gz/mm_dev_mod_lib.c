#include<sys/fcntl.h>
#include<sys/ioctl.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<malloc.h>
#include<pthread.h>

#include"MQTTClient.h"

#include"dis_dev_mod.h"
#include"dis_dev_mod_lib.h"


#define DEV_NAME "mm_motor_mod_dev"

#define MOTOR_IOCTL_START_NUM 0xE551
#define MOTOR_IOCTL_NUM1 MOTOR_IOCTL_START_NUM+1
#define MOTOR_IOCTL_NUM2 MOTOR_IOCTL_START_NUM+2

#define MOTOR_MAGIC_NUM 'm'
#define MOVING_UP _IOWR(MOTOR_MAGIC_NUM, MOTOR_IOCTL_NUM1, unsigned long *)
#define MOVING_DOWN _IOWR(MOTOR_MAGIC_NUM, MOTOR_IOCTL_NUM2, unsigned long *)

#define STR_SIZE 64

void DieWithError(char*);
int MsgWithError(char*);
void make_ip_addr(char*);
int init_MQTT();
int mm_dev_open(void);
int mm_dev_close(int);
int MQTT_running(int);
void* readPIR_function(void*);

extern void delivered(void*, MQTTClient_deliveryToken);
extern int msgarrvd(void*, char*, int, MQTTClient_message*);
extern void connlost(void*, char*);

/* Global variables for MQTTClient */
char clientID[STR_SIZE];
char topic[STR_SIZE];
char ip_addr[STR_SIZE];

/* Global variables for MQTT */
MQTTClient client;
MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
MQTTClient_message pubmsg = MQTTClient_message_initializer;
MQTTClient_deliveryToken token;

/* Die the program when error occur */
void DieWithError(char* mesg){
	char tmp[STR_SIZE];
	
	strncpy(tmp, "DEV_LIB : ", STR_SIZE);
	strncat(tmp, mesg, STR_SIZE);
	perror(tmp);
	exit(-1);
}

/* Message when error occur */
int MsgWithError(char* mesg){
	char tmp[STR_SIZE];

	strncpy(tmp, "DEV_LIB : ", STR_SIZE);
	strncat(tmp, mesg, STR_SIZE);
	perror(tmp);
	return -1;
}

/* Make IP Address */
void make_ip_addr(char* ip){
	strncpy(ip_addr, "tcp://", STR_SIZE);
	strncat(ip_addr, ip, STR_SIZE);
        strncat(ip_addr, ":1883", STR_SIZE);
        printf("%s\n",ip_addr);
}

/* Initializing MQTTClient environment */
int init_MQTT(){
	FILE* fp;
	char ip[STR_SIZE];

	fp = fopen(IP_ADDR_PATH, "r");  //open IP DB
	if(fp < 0)	return MsgWithError("DB file open Error");
	
	fgets(ip, STR_SIZE, fp);  //Get MQTT Broker ip address from Database
        
	strncpy(clientID, DEV_ID, STR_SIZE);
	strncpy(topic, TOPIC, STR_SIZE);
	make_ip_addr(ip);

	fclose(fp);
}

/* Device open */
int mm_dev_open(void){
	int fd;  //file descriptor
	char dev_addr[STR_SIZE];  //Device file path

	/* Making dev_addr device file path */
	strncpy(dev_addr, "/dev/", STR_SIZE);
	strncat(dev_addr, DEV_NAME, STR_SIZE);

	fd = open(dev_addr, O_RDWR);

	if(fd < 0)	return MsgWithError("Device file open Error");
	else		return fd;
}

/* Device close */
int mm_dev_close(int fd){
	int ret;
	
	ret = close(fd);

	if(ret < 0)	return MsgWithError("File close Error");
	else		return 1;
}

/*mqtt test*/
int MQTT_subscribe(int fd){
int rc;
	int ch;
	int tret;

   	MQTTClient_create(&client, ip_addr, "subscriber", MQTTCLIENT_PERSISTENCE_NONE, NULL);
	conn_opts.keepAliveInterval = 20;
	conn_opts.cleansession = 1;

          MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered);

	if((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS){
		printf("Failed to connect, return code %d\n", rc);
		exit(EXIT_FAILURE);
	}
	topic[strlen(topic)]=fd;
         topic[strlen(topic)+1]=NULL;
MQTTClient_subscribe(client, topic, QOS);
       
	

	do{
		ch = getchar();
	}while(ch!='Q' && ch!='q');

	MQTTClient_disconnect(client, 10000);
	MQTTClient_destroy(&client);
	return 0;
}
/*
int MQTT_publish(void){
int rc;
char ch;
char trig[STR_SIZE];

MQTTClient_create(&client, ip_addr, "publisher", MQTTCLIENT_PERSISTENCE_NONE, NULL);
	conn_opts.keepAliveInterval = 20;
	conn_opts.cleansession = 1;

	MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered);

	if((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS){
		printf("Failed to connect, return code %d\n", rc);
		exit(EXIT_FAILURE);
	}


//MQTTClient_subscribe(client, topic, QOS);

strncpy(trig, DEV_ID, STR_SIZE);	
strncat(trig, "-", STR_SIZE);
strncat(trig, HUB_ID, STR_SIZE);
strncat(trig, ":", STR_SIZE);
strncat(trig, "go smoke", STR_SIZE);

pubmsg.payload = trig;
pubmsg.payloadlen = strlen(trig);
pubmsg.qos = QOS;
pubmsg.retained = 0;

MQTTClient_publishMessage(client, topic, &pubmsg, &token);

MQTTClient_publishMessage(client, topic, &pubmsg, &token);

rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);


do{
		ch = getchar();
	}while(ch!='Q' && ch!='q');

	MQTTClient_disconnect(client, 10000);
	MQTTClient_destroy(&client);
d_lib.c:196:4
/*MQTTClient_subscribe(client, topic, QOSd_lib.c:196:4);
       
	

	do{
		ch = getchar();
	}while(ch!='Q' && ch!='q');

	MQTTClient_disconnect(client, 10000);
	MQTTClient_destroy(&client);


   return 0;

}*/


/* MQTT Running 
int MQTT_running(int fd){
	pthread_t readPIR;
	int rc;
	int ch;
	int tret;

	MQTTClient_create(&client, ip_addr, clientID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
	conn_opts.keepAliveInterval = 20;
	conn_opts.cleansession = 1;

	MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered);

	if((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS){
		printf("Failed to connect, return code %d\n", rc);
		exit(EXIT_FAILURE);
	}
	MQTTClient_subscribe(client, topic, QOS);

	tret = pthread_create(&readPIR, NULL, readPIR_function, (void*)(&fd));
	if(tret)
		MsgWithError("Create Thread Error");

	do{
		ch = getchar();
	}while(ch!='Q' && ch!='q');

	MQTTClient_disconnect(client, 10000);
	MQTTClient_destroy(&client);
	return rc;
}*/

/* Read PIR */
/*void* readPIR_function(void* ptr){
	int fd = *((int*)ptr);
	int ret = 0;
	int rc;
	char trig[STR_SIZE];

	strncpy(trig, DEV_ID, STR_SIZE);	
	strncat(trig, "-", STR_SIZE);
	strncat(trig, HUB_ID, STR_SIZE);
	strncat(trig, ":", STR_SIZE);
	strncat(trig, MSG, STR_SIZE);

	while(1){
		if((ioctl(fd, CHECK, NULL) != 0) && (ioctl(fd, SIGNALING, NULL) != 0)){
			printf("PIR Accept signal\n");
			pubmsg.payload = trig;
			pubmsg.payloadlen = strlen(trig);
			pubmsg.qos = QOS;
			pubmsg.retained = 0;
			MQTTClient_publishMessage(client, topic, &pubmsg, &token);
			rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);
		}
	}
}*/
