#ifndef H_DEV_MOD_LIB
#define H_DEV_MDO_LIB

#define HUB_ID "HUB"
#define DEV_ID "DIS"
#define TOPIC "dis_topic"
#define IP_ADDR_PATH "/home/ipdb/ipdb.txt"
#define QOS 1
#define TIMEOUT 10000L

#define MSG "dis trigger"

#endif
